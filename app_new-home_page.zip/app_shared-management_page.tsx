import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"

export default function SharedManagementPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Shared Management</h1>
      <Tabs defaultValue="family">
        <TabsList>
          <TabsTrigger value="family">Family Budget</TabsTrigger>
          <TabsTrigger value="roommates">Roommates Expenses</TabsTrigger>
        </TabsList>
        <TabsContent value="family">
          <Card>
            <CardHeader>
              <CardTitle>Family Budget</CardTitle>
              <CardDescription>Manage shared family expenses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <h3 className="text-lg  font-semibold">Members</h3>
                <div className="mt-2 flex space-x-2">
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" alt="John Doe" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" alt="Jane Doe" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" alt="Kid Doe" />
                    <AvatarFallback>KD</AvatarFallback>
                  </Avatar>
                </div>
              </div>
              <form className="space-y-4">
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="expense-name">Expense Name</Label>
                    <Input id="expense-name" placeholder="e.g., Groceries, Utilities" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="expense-amount">Amount</Label>
                    <Input id="expense-amount" type="number" placeholder="0.00" />
                  </div>
                </div>
                <Button type="submit">Add Shared Expense</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="roommates">
          <Card>
            <CardHeader>
              <CardTitle>Roommates Expenses</CardTitle>
              <CardDescription>Manage shared expenses with roommates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <h3 className="text-lg font-semibold">Roommates</h3>
                <div className="mt-2 flex space-x-2">
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" alt="Alice" />
                    <AvatarFallback>A</AvatarFallback>
                  </Avatar>
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" alt="Bob" />
                    <AvatarFallback>B</AvatarFallback>
                  </Avatar>
                  <Avatar>
                    <AvatarImage src="/placeholder-avatar.jpg" alt="Charlie" />
                    <AvatarFallback>C</AvatarFallback>
                  </Avatar>
                </div>
              </div>
              <form className="space-y-4">
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="expense-name">Expense Name</Label>
                    <Input id="expense-name" placeholder="e.g., Rent, Internet" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="expense-amount">Amount</Label>
                    <Input id="expense-amount" type="number" placeholder="0.00" />
                  </div>
                </div>
                <Button type="submit">Add Shared Expense</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      <div className="mt-6">
        <Link href="/">
          <Button variant="link">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  )
}