import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"

export default function GoalsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Financial Goals</h1>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>New Goal</CardTitle>
            <CardDescription>Create a new financial goal</CardDescription>
          </CardHeader>
          <CardContent>
            <form>
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="goal-name">Goal Name</Label>
                  <Input id="goal-name" placeholder="e.g., Buy a house" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="goal-description">Description</Label>
                  <Input id="goal-description" placeholder="Brief description of your goal" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="goal-amount">Target Amount</Label>
                  <Input id="goal-amount" type="number" placeholder="0.00" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="goal-date">Target Date</Label>
                  <Input id="goal-date" type="date" />
                </div>
              </div>
            </form>
          </CardContent>
          <CardFooter>
            <Button className="w-full">Create Goal</Button>
          </CardFooter>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Current Goals</CardTitle>
            <CardDescription>Track your progress</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between">
                  <h3 className="font-semibold">Buy a house</h3>
                  <span>$50,000 / $200,000</span>
                </div>
                <Progress value={25} className="mt-2" />
              </div>
              <div>
                <div className="flex justify-between">
                  <h3 className="font-semibold">New Car</h3>
                  <span>$15,000 / $30,000</span>
                </div>
                <Progress value={50} className="mt-2" />
              </div>
              <div>
                <div className="flex justify-between">
                  <h3 className="font-semibold">Emergency Fund</h3>
                  <span>$5,000 / $10,000</span>
                </div>
                <Progress value={50} className="mt-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      <div className="mt-6">
        <Link href="/">
          <Button variant="link">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  )
}