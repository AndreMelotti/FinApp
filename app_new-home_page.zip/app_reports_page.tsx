import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

export default function ReportsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Financial Reports</h1>
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Generate Report</CardTitle>
          <CardDescription>Select the type of report you want to generate</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4">
            <Select>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Report Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dashboard">Dashboard Report</SelectItem>
                <SelectItem value="pdf">PDF Report</SelectItem>
                <SelectItem value="excel">Excel Report</SelectItem>
              </SelectContent>
            </Select>
            <Button>Generate Report</Button>
          </div>
        </CardContent>
      </Card>
      <Tabs defaultValue="income-expense">
        <TabsList>
          <TabsTrigger value="income-expense">Income & Expenses</TabsTrigger>
          <TabsTrigger value="investments">Investments</TabsTrigger>
          <TabsTrigger value="debts">Debts</TabsTrigger>
        </TabsList>
        <TabsContent value="income-expense">
          <Card>
            <CardHeader>
              <CardTitle>Income & Expenses Report</CardTitle>
              <CardDescription>Overview of your financial activities</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Category</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Percentage</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Income</TableCell>
                    <TableCell>$5,000.00</TableCell>
                    <TableCell>100%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Housing</TableCell>
                    <TableCell>$1,500.00</TableCell>
                    <TableCell>30%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Transportation</TableCell>
                    <TableCell>$500.00</TableCell>
                    <TableCell>10%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Food</TableCell>
                    <TableCell>$600.00</TableCell>
                    <TableCell>12%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Utilities</TableCell>
                    <TableCell>$300.00</TableCell>
                    <TableCell>6%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Savings</TableCell>
                    <TableCell>$1,000.00</TableCell>
                    <TableCell>20%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Other</TableCell>
                    <TableCell>$1,100.00</TableCell>
                    <TableCell>22%</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="investments">
          <Card>
            <CardHeader>
              <CardTitle>Investments Report</CardTitle>
              <CardDescription>Summary of your investment portfolio</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Investment Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Return</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Stocks</TableCell>
                    <TableCell>$10,000.00</TableCell>
                    <TableCell>8.5%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Bonds</TableCell>
                    <TableCell>$5,000.00</TableCell>
                    <TableCell>3.2%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Real Estate Funds</TableCell>
                    <TableCell>$7,000.00</TableCell>
                    <TableCell>6.8%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Mutual Funds</TableCell>
                    <TableCell>$8,000.00</TableCell>
                    <TableCell>7.1%</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="debts">
          <Card>
            <CardHeader>
              <CardTitle>Debts Report</CardTitle>
              <CardDescription>Overview of your current debts</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Debt Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Interest Rate</TableHead>
                    <TableHead>Monthly Payment</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Mortgage</TableCell>
                    <TableCell>$200,000.00</TableCell>
                    <TableCell>3.5%</TableCell>
                    <TableCell>$1,200.00</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Car Loan</TableCell>
                    <TableCell>$15,000.00</TableCell>
                    <TableCell>4.2%</TableCell>
                    <TableCell>$300.00</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Credit Card</TableCell>
                    <TableCell>$3,000.00</TableCell>
                    <TableCell>18.9%</TableCell>
                    <TableCell>$150.00</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Student Loan</TableCell>
                    <TableCell>$20,000.00</TableCell>
                    <TableCell>5.5%</TableCell>
                    <TableCell>$250.00</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      <div className="mt-6">
        <Link href="/">
          <Button variant="link">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  )
}