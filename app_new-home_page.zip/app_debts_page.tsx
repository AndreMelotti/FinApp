import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import Link from "next/link"

export default function DebtsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Debt Management</h1>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Add New Debt</CardTitle>
            <CardDescription>Record a new debt or loan</CardDescription>
          </CardHeader>
          <CardContent>
            <form>
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="debt-name">Debt Name</Label>
                  <Input id="debt-name" placeholder="e.g., Car Loan" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="debt-amount">Total Amount</Label>
                  <Input id="debt-amount" type="number" placeholder="0.00" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="debt-interest">Interest Rate (%)</Label>
                  <Input id="debt-interest" type="number" placeholder="0.00" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="debt-date">Payment Due Date</Label>
                  <Input id="debt-date" type="date" />
                </div>
              </div>
            </form>
          </CardContent>
          <CardFooter>
            <Button className="w-full">Add Debt</Button>
          </CardFooter>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Debt Overview</CardTitle>
            <CardDescription>Summary of your current debts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between">
                  <h3 className="font-semibold">Total Debt</h3>
                  <span>$50,000</span>
                </div>
                <Progress value={60} className="mt-2" />
                <p className="text-sm text-muted-foreground">60% of annual income</p>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Debt</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Interest</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Mortgage</TableCell>
                    <TableCell>$200,000</TableCell>
                    <TableCell>3.5%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Car Loan</TableCell>
                    <TableCell>$15,000</TableCell>
                    <TableCell>4.2%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Credit Card</TableCell>
                    <TableCell>$3,000</TableCell>
                    <TableCell>18.9%</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
      <div className="mt-6">
        <Link href="/">
          <Button variant="link">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  )
}