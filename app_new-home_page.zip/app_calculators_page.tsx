import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

export default function CalculatorsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Financial Calculators</h1>
      <Tabs defaultValue="compound-interest">
        <TabsList>
          <TabsTrigger value="compound-interest">Compound Interest</TabsTrigger>
          <TabsTrigger value="loan-payment">Loan Payment</TabsTrigger>
        </TabsList>
        <TabsContent value="compound-interest">
          <Card>
            <CardHeader>
              <CardTitle>Compound Interest Calculator</CardTitle>
              <CardDescription>Calculate the growth of your investment over time</CardDescription>
            </CardHeader>
            <CardContent>
              <form>
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="principal">Initial Investment</Label>
                    <Input id="principal" type="number" placeholder="0.00" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="rate">Annual Interest Rate (%)</Label>
                    <Input id="rate" type="number" placeholder="0.00" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="time">Time Period (Years)</Label>
                    <Input id="time" type="number" placeholder="0" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="compound">Compound Frequency</Label>
                    <select id="compound" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                      <option>Annually</option>
                      <option>Semi-annually</option>
                      <option>Quarterly</option>
                      <option>Monthly</option>
                    </select>
                  </div>
                </div>
              </form>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Calculate</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="loan-payment">
          <Card>
            <CardHeader>
              <CardTitle>Loan Payment Calculator</CardTitle>
              <CardDescription>Calculate your monthly loan payments</CardDescription>
            </CardHeader>
            <CardContent>
              <form>
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="loan-amount">Loan Amount</Label>
                    <Input id="loan-amount" type="number" placeholder="0.00" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="loan-term">Loan Term (Years)</Label>
                    <Input id="loan-term" type="number" placeholder="0" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="interest-rate">Annual Interest Rate (%)</Label>
                    <Input id="interest-rate" type="number" placeholder="0.00" />
                  </div>
                </div>
              </form>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Calculate</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
      <div className="mt-6">
        <Link href="/">
          <Button variant="link">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  )
}