import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

export default function PersonalManagementPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Personal Management</h1>
      <Tabs defaultValue="income">
        <TabsList>
          <TabsTrigger value="income">Income</TabsTrigger>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
        </TabsList>
        <TabsContent value="income">
          <Card>
            <CardHeader>
              <CardTitle>Income</CardTitle>
              <CardDescription>Manage your income sources</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="income-source">Income Source</Label>
                    <Input id="income-source" placeholder="e.g., Salary, Freelance" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="income-amount">Amount</Label>
                    <Input id="income-amount" type="number" placeholder="0.00" />
                  </div>
                </div>
                <Button type="submit">Add Income</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="expenses">
          <Card>
            <CardHeader>
              <CardTitle>Expenses</CardTitle>
              <CardDescription>Manage your expenses</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="expense-name">Expense Name</Label>
                    <Input id="expense-name" placeholder="e.g., Rent, Groceries" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="expense-amount">Amount</Label>
                    <Input id="expense-amount" type="number" placeholder="0.00" />
                  </div>
                </div>
                <Button type="submit">Add Expense</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="summary">
          <Card>
            <CardHeader>
              <CardTitle>Financial Summary</CardTitle>
              <CardDescription>Overview of your personal finances</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Total Income:</span>
                  <span className="font-bold">$5,000.00</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Expenses:</span>
                  <span className="font-bold">$3,500.00</span>
                </div>
                <div className="flex justify-between">
                  <span>Balance:</span>
                  <span className="font-bold text-green-600">$1,500.00</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      <div className="mt-6">
        <Link href="/">
          <Button variant="link">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  )
}